# NovaPrime – AgentPhone API starter

This ZIP is a small starter package, **not a copy of the existing deployed NovaPrime website** (its source files were not accessible).

## Included
- `app/api/agentphone/route.ts`: a Next.js server route showing where the `getToken()` call belongs.

## Before using
1. Copy `app/api/agentphone/route.ts` into the existing Next.js project's matching path.
2. Install the `@vercel/connect` package if it is not already installed.
3. Replace `usr_123` with the real authenticated user ID.
4. Add authentication/authorization to the route.
5. Use the token only on the server to call the AgentPhone service. This sample does not place calls or send messages by itself.

Do not deploy this route publicly as-is; it currently lacks user authentication.
