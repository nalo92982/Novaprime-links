import { getToken } from '@vercel/connect';
import { NextResponse } from 'next/server';

/**
 * Example server-side AgentPhone route for NovaPrime.
 * Before production:
 * - Replace the example user ID with the authenticated user's real ID.
 * - Add authentication/authorization to this route.
 * - Use the token server-side to call AgentPhone; never return it to the browser.
 */
export async function POST() {
  try {
    const token = await getToken('agentphone/novaprime-links', {
      subject: {
        type: 'user',
        id: 'usr_123', // Example only; replace with a real user ID
      },
    });

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No AgentPhone token was returned.' },
        { status: 502 }
      );
    }

    // TODO: Use `token` here to call the AgentPhone service server-side.
    return NextResponse.json({
      success: true,
      message: 'AgentPhone token obtained on the server.',
    });
  } catch (error) {
    console.error('AgentPhone token request failed:', error);
    return NextResponse.json(
      { success: false, error: 'AgentPhone connection failed.' },
      { status: 500 }
    );
  }
}
